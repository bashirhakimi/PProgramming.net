document.addEventListener("DOMContentLoaded", function() {
            // Smooth scrolling for navigation links
            document.querySelectorAll("a[href^=\"#\"]").forEach(anchor => {
                anchor.addEventListener("click", function(e) {
                    e.preventDefault();
                    document.querySelector(this.getAttribute("href")).scrollIntoView({
                        behavior: "smooth"
                    });
                });
            });

            // Mobile menu toggle
            const mobileMenuBtn = document.getElementById("mobile-menu-btn");
            const mobileMenu = document.getElementById("mobile-menu");

            mobileMenuBtn.addEventListener("click", function() {
                mobileMenu.classList.toggle("hidden");
                mobileMenuBtn.classList.toggle("hamburger-open");
            });

            // Hide mobile menu when a link is clicked
            mobileMenu.querySelectorAll("a").forEach(link => {
                link.addEventListener("click", function() {
                    mobileMenu.classList.add("hidden");
                    mobileMenuBtn.classList.remove("hamburger-open");
                });
            });

            // Navbar scroll effect
            let lastScrollTop = 0;
            const navbar = document.getElementById("navbar");

            window.addEventListener("scroll", function() {
                let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                if (scrollTop > lastScrollTop) {
                    // Downscroll
                    navbar.classList.remove("nav-visible");
                    navbar.classList.add("nav-hidden");
                } else {
                    // Upscroll
                    navbar.classList.remove("nav-hidden");
                    navbar.classList.add("nav-visible");
                }
                lastScrollTop = scrollTop;
            });

            // Function to scroll to section (for buttons)
            window.scrollToSection = function(id) {
                document.getElementById(id).scrollIntoView({
                    behavior: "smooth"
                });
            };

            // Intersection Observer for section reveal animation
            const sections = document.querySelectorAll(".section-reveal");
            const observerOptions = {
                root: null,
                rootMargin: "0px",
                threshold: 0.1
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            sections.forEach(section => {
                observer.observe(section);
            });

            // Dynamic flowing lines for Hero section
            const flowingLinesContainer = document.querySelector(".flowing-lines");
            if (flowingLinesContainer) {
                for (let i = 0; i < 15; i++) {
                    const line = document.createElement("div");
                    line.className = "flow-line";
                    line.style.top = `${Math.random() * 100}%`;
                    line.style.width = `${200 + Math.random() * 300}px`;
                    line.style.animationDelay = `${Math.random() * 15}s`;
                    flowingLinesContainer.appendChild(line);
                }
            }

            // Dynamic pricing lines
            const pricingLinesContainer = document.querySelector(".pricing-lines");
            if (pricingLinesContainer) {
                for (let i = 0; i < 10; i++) {
                    const line = document.createElement("div");
                    line.className = "pricing-line";
                    line.style.top = `${Math.random() * 100}%`;
                    line.style.animationDelay = `${Math.random() * 8}s`;
                    pricingLinesContainer.appendChild(line);
                }
            }

            // Dynamic about waves
            const aboutWavesContainer = document.querySelector(".about-waves");
            if (aboutWavesContainer) {
                for (let i = 0; i < 8; i++) {
                    const line = document.createElement("div");
                    line.className = "about-line";
                    line.style.top = `${Math.random() * 100}%`;
                    line.style.animationDelay = `${Math.random() * 12}s`;
                    aboutWavesContainer.appendChild(line);
                }
            }

            // Dynamic contact waves
            const contactWavesContainer = document.querySelector(".contact-waves");
            if (contactWavesContainer) {
                for (let i = 0; i < 10; i++) {
                    const line = document.createElement("div");
                    line.className = "contact-line";
                    line.style.top = `${Math.random() * 100}%`;
                    line.style.animationDelay = `${Math.random() * 15}s`;
                    contactWavesContainer.appendChild(line);
                }
            }
        });

